# Handoff: Cairn NVR UI (Dashboard, Events, Event detail, Config)

## Overview
Complete visual design + interaction prototype for Cairn, an event-clip NVR for a home LAN, per the "Cairn NVR — Claude Design Handoff" spec. Four pages: live camera Dashboard (`/`), Events browser (`/events`), Event detail (`/events/:id`), read-only Config (`/config`), plus shared nav chrome and a disk-alert banner. Dark-mode only.

## About the Design Files
The files in this bundle are **design references created in HTML** — a clickable prototype showing intended look and behavior, not production code to copy directly. The task is to **recreate these designs in the target codebase: Phoenix 1.8 LiveView with Tailwind CSS v4 + daisyUI**, translating the inline CSS below into Tailwind utility classes (or a small CSS layer for the custom properties). Pages render inside `<Layouts.app flash={@flash}>`.

`Cairn NVR.dc.html` is the master prototype (all four views in one file, switched client-side; in production these are separate LiveViews/routes). `hs/colors_and_type.css` and `hs/shared.css` are the design-token stylesheets — port the **dark-theme** token values into the Tailwind theme. `image-slot.js` is prototype-only scaffolding (drag-and-drop placeholders standing in for live `<video>` / snapshot `<img>`); do not port it.

## Fidelity
**High-fidelity.** Colors, typography, spacing, radii, and states are final. Recreate pixel-perfectly using the token table below.

## Functional contract (from the backend spec — must be kept verbatim)
- Camera tile: `<article id={"camera-tile-#{cam.id}"}>`, `<h2>{cam.id}</h2>`, `<span id={"camera-status-#{cam.id}"} data-status={status}>`, and the `<video id={"camera-video-#{cam.id}"} phx-hook="MsePlayer" phx-update="ignore" data-camera-id data-hls-url muted autoplay playsinline>` element. In the prototype the video is a placeholder box — in production the `<video>` fills the 16:9 area (`object-fit: cover`); never set `src` (hook owns it).
- Transport toggle buttons: `phx-click="toggle-transport" phx-value-camera={cam.id}`.
- Events filters form: `phx-change="filter"`, `select name="camera"`, `select name="label"`, `input type="date" name="from"/"to"` (empty option = all).
- Events list container: `id="events-list" phx-update="stream"`; child ids from the stream.
- Pagination: `phx-click="page" phx-value-page={n}`.
- Detail video: `<video controls src={"/media/events/#{@event.id}"} poster={snapshot_url}>` — no hook.
- Timeline markers: `data-seek={t}`, hook `TimelineSeek`.
- Config reload button: `phx-click="reload"`.
- Timestamps: `<time datetime={iso}>` with server-formatted local text.

## Design tokens (dark theme — the only theme)
Fonts: sans `Inter` (rsms.me webfont) → system fallbacks; mono `JetBrains Mono`. Body 14px/1.5. Tabular numerics (`font-variant-numeric: tabular-nums`) on every timestamp, duration, score, size readout.

Colors:
- Canvas `#0b0f14`; card surface `#171e26`; sunken wells `#0f141a`; raised `#1e262f`
- Text: primary `#f2f5f8`, secondary `#c3ccd6`, tertiary `#9aa6b3`, faint `#6c7885`
- Borders: card `#2a333d`, divider `#1f2730`, input `#3b4652`
- Accent (primary blue): `#29ade9`; accent-soft bg `rgba(3,169,244,0.12)`; link `#5fc0f5`
- Success `#5ed08a` on `rgba(47,184,102,0.14)`; warning `#f5ba49` on `rgba(240,168,24,0.14)`; danger `#ff7a7e` on `rgba(229,72,77,0.14)`; warm-amber (stalled) `#ffc75c` on `rgba(255,199,92,0.14)`
- REC red `#e5484d`; label chip colors — person `#5fc0f5` on accent-soft, car success, cat `#8b5cf6` on `rgba(139,92,246,0.14)`, dog `#ec4899` on `rgba(236,72,153,0.14)`, package warning

Radii: cards/inputs/buttons 10px; chips 6px; badges/pills 999px. Shadows (dark): card `0 1px 3px rgba(0,0,0,0.4), 0 1px 2px rgba(0,0,0,0.3)`; focus ring `0 0 0 3px rgba(41,173,233,0.45)`. Spacing: 4px grid; page padding 20px; card gaps 16px. Motion: hover/press 150ms, surface 220ms, ease `cubic-bezier(0.2,0,0,1)`; press scales buttons to 0.98; no bounce.

Icons: **Material Symbols Outlined** (weight 400, no fill), via Google Fonts CDN. 15–20px inline, 24px nav/brand, 46px empty states. Names used: terrain (brand), videocam, video_library, tune, hard_drive, schedule, timelapse, chevron_right/left, arrow_back, play_arrow (FILL 1 in the play button only), content_copy, check, warning, error, check_circle, refresh, monitor_heart, public, filter_alt_off, videocam_off, wifi_off, motion_photos_paused, sync_problem.

## Shared chrome
- **Topbar** 56px, surface bg, 1px bottom border, sticky. Left: terrain icon in accent + "Cairn" 16px/700. Nav: three items (Dashboard, Events, Config), 36px tall, 14px/500, radius 10px, icon 19px; active = accent-soft bg + accent text; inactive = secondary text, hover sunken bg. Detail view keeps "Events" active. Right: host `192.168.1.44:4000` mono 12px faint.
- **Disk alert banner** (when `@disk_alert.active`): full-width strip under topbar, warning-soft bg, 10px/20px padding: hard_drive icon (warning color) + "Low disk space — emergency cleanup is deleting the oldest events." (13px/500 primary) + right-aligned mono `1,204 MB free` in warning color. Persistent, does not overlay video.
- Buttons: primary = accent bg, white text; secondary = surface bg + strong border; ghost = transparent, hover sunken. Heights 36px (sm 28px).

## Page 1 — Dashboard
- H1 "Cameras" 22px/600 + inline meta "3 of 5 running · 1 recording" (13px tertiary). Max width 1440px.
- Grid: `repeat(auto-fill, minmax(340px, 1fr))`, 16px gap → 1/2/3 columns responsive.
- **Tile**: card (surface bg, 1px border, radius 10px, overflow hidden). Top: 16:9 video area on sunken bg. Footer row (10px 12px): camera id in mono 13px/500 as `<h2>`, spacer, transport segmented control.
- **Status badge** overlay top-left 10px: pill, bg `rgba(11,15,20,0.78)`, 11px/600, 7px colored dot + label. Six states: connecting = warning + dot pulses (1.4s opacity 1→0.35); running = success; backoff = danger + pulse, label "Unreachable"; stalled = warm amber `#ffc75c`; transcode_unavailable = danger, label "Transcode unavailable"; unknown = tertiary grey.
- **Full-area message overlay** (backoff / stalled / transcode_unavailable): `rgba(11,15,20,0.92)` covering the video area, centered 34px icon in the status color + 13px secondary copy: backoff "We can't reach this camera — retrying every 10 s." (wifi_off); stalled "The stream stopped sending frames. We're restarting it." (motion_photos_paused); transcode_unavailable "This stream needs transcoding but ffmpeg isn't available. Install it or disable transcode for this camera." (sync_problem).
- **Live-event marker** (`@live_events[cam.id]`): red pill top-right ("REC" 11px/700 white + blinking white dot, 1.1s), plus tile border becomes REC red with glow `0 0 0 1px #e5484d, 0 0 18px rgba(229,72,77,0.35)`.
- **Transport toggle**: segmented pill on sunken bg (2px padding), two buttons "Standard" / "Low latency", 11px/600; selected = raised bg + primary text + xs shadow; unselected = transparent + faint text.
- Empty state (no cameras — not in prototype, use pattern): centered 46px videocam icon, "No cameras yet — add one to config.yaml and reload."

## Page 2 — Events
- Max width 1080px. H1 "Events" + live count "16 events" (append " match" when filters active).
- **Filter bar**: one card row, 12px 14px padding, fields inline (Camera 170px, Label 150px, From/To 160px date inputs), label-above-input 13px/500 secondary, inputs 34px. Right: ghost "Clear filters" (filter_alt_off icon) only when filters active.
- **Rows**: vertical stack, 10px gap. Each row = card, flex, 10px 14px padding, pointer, hover bg raised. Contents: 136×76 snapshot thumbnail (radius 6, placeholder when snapshot nil) · info column (camera id mono 13px/500; second line 13px tertiary: schedule icon + "Jul 22, 18:03:11", timelapse icon + duration "52s"/"1m 3s") · right-aligned label chips (radius 6, 12px/500, colored per label, score appended at 11px 75% opacity, 2 decimals) · chevron_right 20px faint. `partial` status: warning badge pill "partial" next to camera id, tooltip "Recording was interrupted".
- **Pagination** footer: left "Showing 1–6 of 16" 13px tertiary; right secondary sm buttons "Previous"/"Next", disabled at 40% opacity. Page size 6 in prototype.
- **Empty state**: centered videocam_off 46px faint, "No events match" 15px/500, "Try widening the date range or removing a filter." 13px tertiary, secondary sm "Clear filters" button.

## Page 3 — Event detail
- Max width 1180px. Ghost back button "← Back to events" (patch nav, preserves filters).
- Two-column grid: `minmax(0,1fr) 300px`, 16px gap.
- **Player card**: 16:9, poster snapshot, centered 64px play affordance (prototype only — production uses native `<video controls>`). Bottom scrub strip is prototype-only illustration.
- **Detections card** below: header "Detections" 14px/600 + hint "click a marker to seek" 12px tertiary. One row per label: 72px right-aligned label (12px/500 in label color) + full-width 26px track (sunken bg, radius 6). Markers: 13px circles in label color, 2px surface border, positioned `left = t/duration %`, title tooltip "person 0.91 at 0:12", `data-seek={t}`. Clicking seeks; an accent 2px playhead line spans the rows at the current position (220ms ease transition). Axis under tracks: 0:00 / mid / end, 11px faint, tabular.
- **Metadata panel** (right card): header row camera id (mono 14px/500) + status badge (finalized = success, partial = warning). If partial: warning note "Recording was interrupted — the clip may end early." Then key/value rows divided by 1px dividers, 13px (keys tertiary 84px, values right): Started, Ended, Duration, File size ("13.7 MB", 1 decimal), Max score (mono, 2 decimals), Clip path (mono 11px). Footer: full event uuid mono 11px faint + copy icon button (content_copy → check for 1.5s).

## Page 4 — Config
- Max width 980px, single column, 16px gaps.
- Header: H1 "Config" + sub "Read-only view of `/etc/cairn/config.yaml` — edit the file, then reload." Right: primary button "Reload config" (refresh icon; while loading: icon spins, label "Reloading…", disabled).
- **Reload result — success**: card with success-colored border, check_circle + "Config reloaded — changes are live" (14px/600 success); diff chips row (success badge "added carport", accent badges "changed front_door", "changed side_gate"); warnings list in warning color, 13px, warning icon per line.
- **Reload result — failure**: danger-bordered card, error icon + "We couldn't load the new config"; errors in mono 13px danger (e.g. `cameras.carport.rtsp_url is missing`); footer note "Your previous config is still active — nothing changed." (13px secondary).
- **Config health card**: monitor_heart header, persistent warning lines (`@last_load.warnings/errors`) with icons.
- **Globals card**: grid `auto-fill minmax(210px,1fr)`, each cell = uppercase 11px/600 tertiary key + mono 13px value (data_dir, retention, pre/post-roll, UDP range, min_score default, snapshot, cleanup sweep).
- **Camera cards**: grid `auto-fill minmax(400px,1fr)`. Each: header (camera id mono 14px/500 + right-aligned chips: accent "transcode" badge when flag on; warning "not H.264" chip; danger "transcode unavailable" chip) · masked rtsp_url in mono 12px on sunken block (radius 6, 8px 10px, password pre-masked as `•••••`) · probe chips row (mono 12px on sunken: codec / WxH / fps / profile; unreachable camera shows single warning-colored "not probed yet — camera unreachable") · 2-col key/value rows (plugin, min_score map, windows, retention).

## State management (per LiveView)
- Dashboard: `@cameras` w/ status map, `@live_events` (camera_id ⇒ true), `@disk_alert`, per-camera transport choice.
- Events: filter params (camera, label, from, to), page, stream of events, total count.
- Detail: `@event`, seek position (client hook), copied-feedback is client-only.
- Config: `@config`, `@last_load` (warnings/errors), reload in-flight flag, last reload result (diff/warnings or errors).

## Assets
No raster assets. Inter + JetBrains Mono + Material Symbols Outlined via CDN. All placeholder frames stand in for camera snapshots/streams.

## Files
- `Cairn NVR.dc.html` — master prototype (all 4 views; template markup + a logic class with mock data and handlers)
- `hs/colors_and_type.css` — full token sheet (use `[data-theme="dark"]` values)
- `hs/shared.css` — component primitives (buttons, inputs, cards, badges, table)
- `image-slot.js` — prototype-only placeholder component; do not port


---

# Round two — Track viewer (Jul 31, 2026)

New in this round: the **Tracks** page, the **Tracked objects** panel on Event detail, and the **bbox canvas overlay**. Round-one tokens and primitives carry over unchanged; **no additions to hs/shared.css were needed** — everything below composes from existing primitives.

## Answers to the open questions

1. **Nav placement**: fourth topbar item ("Tracks", glyph `route`), between Events and Config. Tracks answers a different question than Events ("what did the system *see*", not "what did it record"), so burying it as an Events sub-tab misfiles it; the 56px bar carries four items comfortably. When Event detail is opened *from* a track row, the Tracks nav item stays active and the back button reads "Back to tracks".
2. **Per-object colors**: **hybrid — label hue, varied per object.** Each label owns a 3-step palette (e.g. person: #5fc0f5 / #29ade9 / #9fd8f8); an object's color is `palette[label][nth % 3]`, where `nth` is the object's ordinal among same-label tracks on the event, ordered by `started_at`. Color still *means* label at a glance, but two people in frame are distinguishable. Row swatch and canvas box derive from the same `(label, nth)` input, so one Elixir helper (mirroring `label_color/1`) serves both. Unknown/nil label uses the person palette.
3. **Transitions**: **collapse stationary runs.** A `became_stationary … started_moving` pair renders as one row — `motion_photos_paused 0:16 stationary · for 2h 14m` — seeking to the run start. The run's end is implied by the next row's timestamp. Every moment stays in the data; only the presentation collapses. A bare `started_moving` (no preceding stationary) renders verbatim (`north_east`).

## Tracks page (/tracks)

Same 1080px shell, filter-bar card, row-card stack, pagination, and empty state as Events — built from `.hs-card`, `.hs-field`, `.hs-input`, `.hs-btn--secondary/--ghost/--sm`, label chips, `.tnum`.

- Row anatomy (text only, no thumbnail): label chip + score (2 decimals, `—` when nil) · camera mono 13px/500 · `<time>` start with `schedule` icon · duration with `timelapse` (`—` while live) · zone chips (mono 11px on sunken bg, max 2 shown then "+N", `—` when empty) · right-aligned `end_reason` · link affordance.
- **end_reason** is NOT shown on the row surface — nearly every row would read "unseen", which is noise at browse level. It appears only as the muted suffix on the "ended" moment (row expansion and Event-detail panel), with a plain-language tooltip gloss (e.g. `evicted` → "Dropped to cap memory use").
- **Unlinked rows** (the common case): no chevron, no pointer, no hover lift; a quiet 12px `--hs-fg-4` note — "not recorded" (`event_id` nil) or "clip expired" (event pruned). Reads as normal, not as an error.
- **Live rows**: `hs-badge--success` "live" with pulsing dot; duration and end_reason `—`/absent.
- Contract kept verbatim: `phx-change="filter"` with `camera/label/zone/from/to` selects+dates, `id="tracks-list"`, `phx-click="page" phx-value-page`, row link → `~p"/events/#{event_id}?track=#{object_id}"`.

## Event detail — Tracked objects panel

Kept **in the 300px right column, second card under #event-meta**. Transition rows are just icon + clock + kind — they fit 300px comfortably, and keeping the panel beside the player means the color swatches sit next to the boxes they describe; a full-width card below the timeline would push them below the fold.

- Object row: 10px color swatch (solid = selected, 2px outline = unselected) + label chip + score, visibility toggle (`visibility`/`visibility_off`, carries `phx-click="toggle-track" phx-value-id`), disclosure (`expand_more`/`expand_less`). Unselected rows drop to 55% opacity.
- Transitions live inside `id="track-moments"` with `phx-hook="TimelineSeek"`, `data-video-id="event-clip"`, `data-event-seconds` — rows are `<button data-t={t}>` so the hook can rewrite pre-roll-corrected seeks. Expansion state is assumed **server-side would be fine as client-only `<details>`**; the prototype keeps it client-side.
- Moment glyphs: `trip_origin` appeared · `motion_photos_paused` stationary (collapsed run) · `north_east` started moving · `flag` ended (reason as muted suffix).
- Zero-moment track: muted line "No moments — it appeared and was evicted."
- **States** (Tweaks → "Track panel"): *no tracks* → panel empty state ("No tracked objects — this clip predates tracking, or its tracks have aged out"); *still recording* → info note "Still recording — tracks appear here as they end." over the partial list; *no track file* → **disable, don't hide**: toggles disabled at 40% with note "We couldn't find this clip's track file, so there are no boxes to draw. Moments still seek." Hiding would make the feature look absent on exactly the clips users debug.

## Bbox overlay

Contract markup kept verbatim: `#track-overlay-wrap` with `phx-hook="TrackOverlay"`, `data-video-id`, `data-sidecar-url`, `data-event-seconds`; `<canvas id="track-overlay" phx-update="ignore">` absolutely filling the video box, `pointer-events: none` on wrap and canvas.

- **Box**: 2px stroke in the object color, 3px corner radius, **no fill**, over a 4px `rgba(4,8,12,0.55)` halo stroke — legible on daylight and IR frames without occluding the subject.
- **Label affix**: 11px chip anchored above-left of the box — `label score` in the object color on `rgba(11,15,20,0.82)`; flips inside the box when it would clip the top edge.
- **Frame edge**: boxes clip naturally at the canvas edge (no special treatment).
- **Predicted boxes**: identical — v1 carries no flag, so there is nothing to design.
- **Truncated sidecar**: silence is acceptable for v1 — boxes stopping mid-clip reads as "the object left". If it turns out confusing, a one-line note in the panel ("boxes end at 4:12 — capture cap") is the cheap fix; don't build UI for it yet.
- Recommend the hook skips drawing over the bottom 44px native-controls strip while controls are visible.

## New Material Symbols glyphs (complete list)

`route` (nav + empty states) · `trip_origin` · `motion_photos_paused` · `north_east` · `flag` · `visibility` · `visibility_off` · `expand_more` · `expand_less`. (All others were already in round one.)


## Addendum — unlinked rows expand in place

A track with no clip (not recorded / clip expired) still has its moments in the DB, so its row on /tracks **expands in place**: clicking the row toggles an inset section listing the transitions (same glyphs and collapsed-stationary rule as the Event-detail panel, clocks as offsets from track start in m:ss / h:mm:ss), plus the object_id ULID and a quiet "never recorded — moments only" / "clip expired — moments only" hint. Affordance is `expand_more`/`expand_less` where linked rows show `chevron_right`; all rows are now pointer + hover-raised. Linked rows still navigate — the clip view is strictly better when it exists. Live rows expand too (stationary shows "ongoing"). Contract note: expansion can be client-only; no new phx events needed.


## Addendum — live tracks

Live rows (`ended_at` nil) now show **elapsed time so far** in the duration column (same `timelapse` icon; `fmt_duration` extended to hours: "2h 40m") alongside the pulsing "live" badge, instead of "—". Expanding a live row shows moments so far; an ongoing stationary run reads `motion_photos_paused 9:00 stationary · ongoing — 2h 31m so far`. Server-side this is `now() - started_at` (and `now() - last became_stationary`), rendered at mount — no ticker needed at this fidelity. Demo row: a parked car on `garage`, stationary for hours and still live.


---

# Round two, rev B — multi-clip tracks (spec v2)

## Answer to open question 4 — cross-clip affordance

**Inline, not grouped.** Cross-clip transition rows render as links: absolute time (mono, `--hs-blue-300`) instead of a clock offset, kind text in the same link blue, and a right-aligned `arrow_outward` glyph. In-clip seek rows keep the neutral `--hs-fg-2` offset clock and no arrow — the color + absolute-time + arrow triple makes the two unmistakable at a glance. Per-clip subheadings were rejected: the arrival↔departure case is 2 clips and ~6 rows in a 300px panel; grouping adds chrome without aiding the hop. Tooltip on link rows: "In another clip — open <camera> at <offset>".

## Transition row variants (contract)

- **In this clip** — `<button data-t={t}>` inside the `TimelineSeek`-hooked `#track-moments` region; offset clock (`fmt_clock/1`).
- **In another clip** — `<.link navigate={~p"/events/#{other_id}?track=#{object_id}&t=#{seconds}"}>`; absolute time, link color, `arrow_outward`. Not a `data-t` button.
- **Not recorded** — inert row at 60% opacity, absolute time in `--hs-fg-3`, suffix "· no clip".
- `?track=` pre-selects + expands the object; `?t=` seeks after `loadedmetadata` — both exercised by the prototype's cross-clip hop.

## Demo scenario

The driveway car (`01J8DRIVEWAYCARSPAN0000001`) spans two clips: arrives in `f16c48a7` (15:12), parks unrecorded for ~2.5h (one repositioning — inert "no clip" rows), leaves in `a71e0c44` (17:41). Its panel row appears on both event pages; each page seeks its own moments and links across to the other clip. The /tracks row links to the **first** recorded clip (`f16c48a7`), duration "2h 28m".

## Other v2 alignments

- Unlinked /tracks rows now say **"no clip"** uniformly (never-recorded and pruned collapse to one quiet state at browse level; the expansion hint still distinguishes "never recorded" vs "clips pruned").
- `fmt_duration` hour form ("2h 28m") used on all track durations.
- Panel lists tracks **overlapping the clip window**, not only tracks that ended in it.
- Deliberate deviation: unlinked rows DO keep pointer + hover, because they expand in place to show moments (earlier addendum) — they are interactive, just not navigable.
